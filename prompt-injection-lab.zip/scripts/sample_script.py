# Python harness for automated prompt injection
print('Test harness')