# Bash automation script
echo 'Test script'