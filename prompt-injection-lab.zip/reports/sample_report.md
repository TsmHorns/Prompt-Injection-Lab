# Vulnerability Report
Formalized notes for hiring managers