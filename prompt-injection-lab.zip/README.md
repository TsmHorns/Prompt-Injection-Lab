# Prompt Injection Lab

## About
Adversarial prompt engineer, HackAPrompt competitor.

## Documented Wins
- 2-try win, 59-try persistence grind, etc.

## Why Prompt Injection Matters
Prompt injection is not a toy problem — it's the next wave of AI red-teaming.

## Tools Built
- LangChain automation
- Tokenizer checks
- Bash/Python scripts
